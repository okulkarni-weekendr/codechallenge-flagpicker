package com.hubspot.api.codechallenge.constants;

public class RestConstants {
    public static class URI {
        public static final String MAIN_URI = "/";
    }
}
