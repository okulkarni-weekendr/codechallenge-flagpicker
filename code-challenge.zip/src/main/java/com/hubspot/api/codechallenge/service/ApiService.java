package com.hubspot.api.codechallenge.service;

import com.fasterxml.jackson.core.JsonProcessingException;

public interface ApiService {
    public int postInvitationInfo() throws JsonProcessingException;
}
