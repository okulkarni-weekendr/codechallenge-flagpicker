package com.hubspot.api.codechallenge.model;

import java.util.List;

public class ApiResponse {
    private List<InvitationInfo> countries;

    public ApiResponse(List<InvitationInfo> countriesInvitationInfo) {
        this.countries = countriesInvitationInfo;
    }

    public List<InvitationInfo> getCountries() {
        return countries;
    }

    public void setCountries(List<InvitationInfo> countries) {
        this.countries = countries;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
