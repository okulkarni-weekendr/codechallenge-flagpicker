package com.hubspot.api.codechallenge.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hubspot.api.codechallenge.constants.RestConstants.URI;
import com.hubspot.api.codechallenge.service.ApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApiController {

    @Autowired
    private ApiService apiService;

    @RequestMapping(value = URI.MAIN_URI)
    public int index() throws JsonProcessingException {
        return apiService.postInvitationInfo();
    }
}
