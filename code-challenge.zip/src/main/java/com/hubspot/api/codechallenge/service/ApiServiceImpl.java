package com.hubspot.api.codechallenge.service;

import com.hubspot.api.codechallenge.model.ApiResponse;
import com.hubspot.api.codechallenge.model.InvitationInfo;
import com.hubspot.api.codechallenge.model.Partner;
import com.hubspot.api.codechallenge.model.Partners;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ApiServiceImpl implements ApiService{

    private final DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

    @Autowired
    private RestTemplate restTemplate;

    private final String GET_URL =
            "https://candidate.hubteam.com/candidateTest/v3/problem/dataset?userKey=451be323a7b17e639e6d5db71094";

    private final String POST_URL =
            "https://candidate.hubteam.com/candidateTest/v3/problem/result?userKey=451be323a7b17e639e6d5db71094";

    /**
     * For each country,
     * 1. create a map of date and set of partners
     * 2. sort the dates
     * 3. Iterate through the list of dates, if the dates are consecutive,
     *    find the intersection of partners and update the startDate and listOfPartners.
     * 4. return an invitation info object back.
     * @param partnerList
     * @return Invitation info object.
     */
    private InvitationInfo getInvitationInfoForPartners(List<Partner> partnerList){
        Map<Date, HashSet<String>> listOfPartnersByDate = new HashMap<>();

        partnerList.forEach(partner -> {
            List<Date> dates = partner.getAvailableDates();
            dates.forEach(date -> {
                if(!listOfPartnersByDate.containsKey(date)){
                    listOfPartnersByDate.put(date, new HashSet<>(Collections.singletonList(partner.getEmail())));
                }else{
                    HashSet<String> newListOfPartners = listOfPartnersByDate.get(date);
                    newListOfPartners.add(partner.getEmail());
                    listOfPartnersByDate.put(date, newListOfPartners);
                }
            });
        });

        List<Date> listOfDates = listOfPartnersByDate
                .entrySet()
                .stream()
                .map(Map.Entry::getKey)
                .sorted().collect(Collectors.toList());

        Date startDate = null;
        int maxPartnersSoFar = Integer.MIN_VALUE;
        List<String> listOfMostPartners = new ArrayList<>();

        for(int i = 0; i < listOfDates.size() - 1; i++){
            Date d1 = listOfDates.get(i + 1);
            Date d2 = listOfDates.get(i);
            int diffDays = (int)(d1.getTime() - d2.getTime())
                    / (1000 * 60 * 60 * 24);

            if(diffDays == 1){
                Set<String> intersection = new HashSet<>(listOfPartnersByDate.get(d1));
                intersection.retainAll(listOfPartnersByDate.get(d2));
                if(intersection.size() > maxPartnersSoFar){
                    maxPartnersSoFar = intersection.size();
                    startDate = d2;
                    listOfMostPartners = new ArrayList<>(intersection);
                }
            }
        }

        return new InvitationInfo(maxPartnersSoFar, listOfMostPartners, df.format(startDate));
    }


    /**
     * Post the final results to the post url.
     * @return status code
     */
    @Override
    public int postInvitationInfo() {
        List<Partner> listOfPartners = Objects.requireNonNull(restTemplate
                .getForObject(GET_URL, Partners.class))
                .getPartners();

        Map<String, List<Partner>> byCountry = listOfPartners
                .stream()
                .collect(Collectors.groupingBy(Partner::getCountry));

        List<InvitationInfo> countriesInvitationInfo = new ArrayList<>();

        byCountry.forEach((key, value) -> {
                InvitationInfo info = getInvitationInfoForPartners(value);
                info.setName(key);
                countriesInvitationInfo.add(info);
        });

        ApiResponse response = new ApiResponse(countriesInvitationInfo);

        return restTemplate.postForEntity(POST_URL, response, ApiResponse.class).getStatusCodeValue();
    }
}
